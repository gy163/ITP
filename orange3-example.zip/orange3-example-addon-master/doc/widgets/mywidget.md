Hello World
===========

![image](icons/mywidget.png)

A dummy widget that greets the world.

Signals
-------

- (None)

**Outputs**:

- (None)

Description
-----------

This is a simple widget that greets the world using a QLabel. If you are interested in widget development, you should take a look at it's source code.
